# 7TH LAYER SIMPLE WEBSOCKET SERVER
## Nama kelompok : SatuPaketLoss

## Cara Penggunaan
1. Jalankan server dengan mengeksekusi "py server.py" di terminal.
2. Jalankan client dengan mengeksekusi "client.html" di peramban.
3. Lakukan simulasi dengan mengirim pesan, submisi, dan sebagainya

## Pembagian kerja kelompok
1. 13516080 - Putra Hardi Ramadhan      -> Testing
2. 13517022 - T. Antra Oksidian Tafly   -> Testing, Implementasi kode
3. 13517065 - Andrian Cedric            -> Testing, eksplorasi websocket